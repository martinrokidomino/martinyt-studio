﻿import discord, logging, json
import asyncio
import os

logger = logging.getLogger('discord')
logger.setLevel(logging.DEBUG)
handler = logging.FileHandler(filename='log.txt', encoding='utf-8', mode='w')
handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s:%(name)s: %(message)s'))
logger.addHandler(handler)

from discord.ext import commands
from discord.utils import get

bot = commands.Bot(command_prefix="mp!")
bot.load_extension("jishaku")
bot.remove_command('help')

@bot.event
async def on_ready():
    print("------------------------")
    print(bot.user.name)
    print("------------------------")

@bot.command()
async def привет(ctx):
    author = ctx.message.author
    await ctx.send('Привет!')

@bot.command()
async def инфо(ctx):
    author = ctx.message.author
    await ctx.send('О боте\nЭто бета версия\nБот находится в стадии разработки\nВерсия:Релиз 1.0')

@bot.command()
async def хелп(ctx):
    author = ctx.message.author
    await ctx.send('Список команд бота\nmp!хелп - Список команд бота логично же\nmp!привет - Скажи боту привет и он тебе скажет привет\nmp!инфо - О боте\nmp!лечьвдурку - Записаться и лечь в дурку\nmp!вернуться - Вернуться из дурки\nmp!очистить - Очистить чат (необходимо указать число сообщений)\nmp!новости - Что нового, так скажем это Changelog\nmp!аватар - Аватарка пользователя\nmp!эмоция - Позволяет скачать эмодзи\nmp!инвайт - Пригласить бота на сервер\nmp!эльдорадо - Вы смотрите рекламу МОЩНОГО КОМПА ОТ ИРБИС \nmp!планирование - Все что планируется на будущее \nmp!расписание - Логично по названию команды')

@bot.command()
async def лечьвдурку(ctx):
    author = ctx.message.author
    await ctx.send('Вы успешно легли в дурку!')

@bot.command()
async def вернуться(ctx):
    author = ctx.message.author
    await ctx.send('Вы вернулись из дурки')

@bot.command()
@commands.has_permissions(administrator = True)
async def очистить(ctx):
    val = str(ctx.message.content)
    val = int(val[11:])
    await ctx.channel.purge(limit = val)

@bot.command()
async def meme(ctx):
    author = ctx.message.author
    await ctx.send('Салон оптики слепая курица\nДетский магазин мелкий пиздюк\nСеть аптек больной ублюдок\nСекс-шоп ебучий случай\nАгентство ритуальных услуг ебать копать')

@bot.command()
async def новости(ctx):
    author = ctx.message.author
    await ctx.send('Новости бота\n\nБот переписан на основе старого бота')

@bot.command(aliases = ["avatar", "Avatar", "Аватар"])
async def аватар(ctx, *, avamember: discord.Member):
    emb = discord.Embed(title = f"Аватар {avamember.name}", colour = discord.Color.blue())
    emb.set_image(url = avamember.avatar_url)
    await ctx.send(embed = emb)

@bot.command(aliases = ["emoji"])
async def эмоция(ctx, emoji: discord.Emoji):
     emb = discord.Embed(title = f"{emoji.name}", colour = discord.Color.blue())
     emb.set_image(url = emoji.url)
     await ctx.send(embed = emb)

@bot.command()
async def инвайт(ctx):
     author = ctx.message.author
     await ctx.send("https://discord.com/api/oauth2/authorize?client_id=777549612260130847&permissions=8&scope=bot")

@bot.command()
async def эльдорадо(ctx):
    author = ctx.message.author
    await ctx.send('Мощнейщий компьютер ирбис\n\n4 ядра 4 гига игровая видеокарта\n за 17999 рублей \n Эльдорадо учитесь как надо')

@bot.command()
async def нашсайт(ctx):
    author = ctx.message.author
    await ctx.send('https://martinrokidomino.github.io/martinyt-studio/html/main.html')

@bot.command()
async def новостисайта(ctx):
    author = ctx.message.author
    await ctx.send('Чаты не обновляются, Простите за неудобства')

@bot.command()
async def faq(ctx):
    author = ctx.message.author
    await ctx.send('FAQ\n Почему бот переежает на python?\n Ответ: Более усовершествованный язык программирование чем дбд\n Будет ли премиум версия бота?\n Ответ: Да, Если разберусь с рандомным текстом')

@bot.command()
async def планирование(ctx):
    author = ctx.message.author
    await ctx.send('Добавить премиум версию бота\nНовые планирование будут позже!')

@bot.command()
async def расписание(ctx):
    author = ctx.message.author
    await ctx.send('14.00-16.00 - Дневная работа\n 16:00-21:00 - Вечерняя-Ночная работа')


bot.run("Nzc3NTQ5NjEyMjYwMTMwODQ3.X7FDgQ.mge1IQ0crOFaceuq29BtX_ieAnk")
